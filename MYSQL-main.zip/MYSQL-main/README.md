# MYSQL
Video tutorials of these sessions are available on youtube channel codstudioByPrachiGupta  . Link given below
https://www.youtube.com/playlist?list=PLnNg6KqJ3HGg-GGIMi4d6RYXRpFcTfURi
